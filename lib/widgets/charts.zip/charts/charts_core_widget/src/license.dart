part of core;

//ignore: avoid_classes_with_only_static_members
/// The class for license validation.
@Deprecated('License registration is not required now')
class SyncfusionLicense {
  /// <summary>
  /// Method to validate the license and display popup.
  /// </summary>
  /// <param name="context">context</param>
  // ignore: missing_return
  static String? validateLicense(BuildContext context) {}

  /// <summary>
  /// Method to register the license key.
  /// </summary>
  /// <param name="licenseKey">licenseKey</param>
  static void registerLicense(String licenseKey) {}
}
