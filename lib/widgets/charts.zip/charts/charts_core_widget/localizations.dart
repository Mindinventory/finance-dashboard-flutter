export './src/localizations/global_localizations.dart';
