library legend_internal;

export 'src/legend/legend.dart';
