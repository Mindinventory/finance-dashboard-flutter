library tooltip_internal;

import 'dart:async';
import 'dart:ui';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/rendering.dart';
import 'package:flutter/material.dart';

import 'core.dart';

part 'src/tooltip/tooltip.dart';
